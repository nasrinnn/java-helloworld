# java-hello-world
A simple docker example to demonstrate Java's HelloWorld program.
